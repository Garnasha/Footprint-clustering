#Acknowledgements
*TODO: Bulletlist -> Fulltext*
 - defaults (supervisors etc.)
 - Human Genome Consortium (reference genome)
 - Research group (via Sadia) which produced dataset. Mention anonymous
   (blood) donors. 

The dataset we have used has been produced by the stellar work of (*
Insert credits for dataset here *), who has/have our deep gratitude and
without whose generosity in sharing their test results this thesis would
have been impossible.
