#Conclusion
The dataset has turned out to not be amenable to analysis by simple MST
using a Hamming metric. Several improvements are thinkable, some of
which are based on the little information which the approach used here
revealed. However, implementing such improvements is beyond the scope of
this thesis.
