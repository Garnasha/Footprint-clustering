\newcommand{\nA}{\text A}
\newcommand{\nC}{\text C}
\newcommand{\nT}{\text T}
\newcommand{\nG}{\text G}

\newcommand{\Sequences}{\text{Sequences}}
\newcommand{\Locations}{\text{Locations}}
\newcommand{\lookup}{\operatorname{lookup}}
\newcommand{\Wildcard}{\text{Wildcard}}
\newcommand{\join}{\operatorname{join}}
