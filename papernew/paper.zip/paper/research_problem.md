#Research problem

The goal of this thesis is as follows: Write a program that, given a
dataset such as the one described above/below **FIXME**, produces a list
of likely common motifs explaining the dataset, with the implication
that these motifs should match the motifs recognized by the actual TFs
active in the cell from which the dataset arises.

*TODO* hier verder.
