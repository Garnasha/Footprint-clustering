#Research Problem for Biologists

The goal of this thesis is as follows: Write a program that, given a
dataset such as the one we have, produces a list of likely common motifs
explaining the dataset, with the implication that these motifs should
match the motifs recognized by the actual transcription factors active
in the cell from which the dataset arises.
